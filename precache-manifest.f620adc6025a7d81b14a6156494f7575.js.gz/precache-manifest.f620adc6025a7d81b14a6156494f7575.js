self.__precacheManifest = [
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/RNWW/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "d9737938d40f3338cc89",
    "url": "/RNWW/static/js/app.7fd568d2.chunk.js"
  },
  {
    "revision": "fe2e362ff1ec7d005106",
    "url": "/RNWW/static/js/runtime~app.842ecc4b.js"
  },
  {
    "revision": "6165c9d7a2e729ba57b23dd93add5366",
    "url": "/RNWW/static/media/back-icon-mask.6165c9d7.png"
  },
  {
    "revision": "c7578911196974808febf223f05a8364",
    "url": "/RNWW/static/media/robot-prod.c7578911.png"
  },
  {
    "revision": "54da1e9816c77e30ebc5920e256736f2",
    "url": "/RNWW/static/media/robot-dev.54da1e98.png"
  },
  {
    "revision": "761a29cc5b9163dd2a23118c3d85605d",
    "url": "/RNWW/static/media/expo-icon.761a29cc.png"
  },
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/RNWW/./fonts/Foundation.ttf"
  },
  {
    "revision": "d9e4e405e6ecd37aa73fd98ac320f57f",
    "url": "/RNWW/index.html"
  },
  {
    "revision": "c705f2074da44eeb5420c53a83b3cbea",
    "url": "/RNWW/manifest.json"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/RNWW/serve.json"
  },
  {
    "revision": "22dc6f920f05869d2ed0",
    "url": "/RNWW/static/js/2.d34e8b4a.chunk.js"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/RNWW/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/RNWW/./fonts/Ionicons.ttf"
  },
  {
    "revision": "5e695e96a003a79f7f97060bf49409a9",
    "url": "/RNWW/expo-service-worker.js"
  },
  {
    "revision": "49a79d66bdea2debf1832bf4d7aca127",
    "url": "/RNWW/./fonts/SpaceMono-Regular.ttf"
  },
  {
    "revision": "5a293a273bee8d740a045d9922b9a9ae",
    "url": "/RNWW/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/RNWW/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "/RNWW/favicon.ico"
  },
  {
    "revision": "872545dde71de3842234bf6afe80c4cb",
    "url": "/RNWW/./fonts/FontAwesome5_Solid.ttf"
  },
  {
    "revision": "c6aef942e3668158ec29d4adcb2e768f",
    "url": "/RNWW/./fonts/FontAwesome5_Brands.ttf"
  },
  {
    "revision": "6beba7e6834963f7f171d3bdd075c915",
    "url": "/RNWW/./fonts/Feather.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/RNWW/./fonts/Entypo.ttf"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/RNWW/./fonts/AntDesign.ttf"
  }
];